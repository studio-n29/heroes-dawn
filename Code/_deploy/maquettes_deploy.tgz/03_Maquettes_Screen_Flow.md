# Maquettes & screen flow

> Rendu cible du **jeu complet** (19 écrans du document `01_UX_Ecrans.md`), en paysage 1920×1080.
> **Wireframes** = structure et contenu (niveaux de gris, pastilles rouges renvoyant aux légendes).
> **Maquettes stylisées** = intention visuelle, DA comics de référence *Secret Wars* (2015).
> Les portraits des maquettes sont provisoires (extraits de l'illustration clé). Images dans `Maquettes/`, scripts de génération dans `Maquettes/_sources/`.

## 1. Screen flow

![Screen flow](Maquettes/flow/F01-screen-flow.png)

- Le **QG** est le hub : 5 pièces (salon, infirmerie, opérations, labo, archives) et 5 menus permanents (recrutement, équipe, pass, boutique, paramètres).
- La **boucle de mission** : carte → préparation → plateau → case (combat, mini-jeu, événement, repos) → résultats → plateau.
- Sorties de la boucle : zone sécurisée ou escouade épuisée → QG ; « Retour QG » depuis le plateau referme le brouillard.
- Le **prologue** ne se joue qu'au premier lancement, puis mène au QG.

## 2. Parcours joueur

![Parcours joueur](Maquettes/flow/F02-parcours.png)

- **Session type (5-10 min)** : collecter au QG, reprendre la zone, 2 à 4 lancers, un combat, résultats.
- **Premier lancement (~5 min)** : scène d'introduction, mini-plateau scripté de 8 cases, premier combat avec combo guidé, arrivée au QG, recrutement gratuit.
- **Boucle de retour (2 min)** : labo, expéditions (récupérer puis relancer), infirmerie, pool de recrutement.

## 3. Règles de conception

- Format de référence : paysage 1920×1080 (mise à l'échelle 0,5 largeur/hauteur). Zone de sécurité mobile : 88 px de chaque côté (pointillés rouges sur les wireframes), aucun élément interactif dedans.
- Cibles tactiles : 96 px minimum en 1080p (environ 9 mm), 24 px d'écart entre deux boutons voisins.
- Placement constant : retour en haut à gauche, ressources et ⚙ en haut à droite, action principale en bas à droite (zone du pouce droit).
- Une seule action principale par écran (bouton jaune ou rouge) ; les actions secondaires sont sombres.
- Au plus une modale ouverte au-dessus d'un écran (confirmation comprise) ; le plateau et le combat se mettent en pause derrière une modale, sauf le temps actif du combat qui ne s'arrête que pour la retraite.
- Couleur jamais seule porteuse d'information : chaque famille a aussi son icône, chaque état a aussi un libellé (accessibilité daltonisme).
- Textes : Bangers pour les titres, boutons et chiffres ; Comic Neue pour tout texte de plus de 4 mots. Taille minimale 20 px en 1080p.
- PC : tout est cliquable à la souris ; raccourcis indiqués entre crochets sur les boutons ([Q], [W], [E], Espace…).

## 4. Wireframes annotés

| Réf. | Écran |
|---|---|
| W01 | Titre / connexion |
| W02 | QG — hub (vue en coupe) |
| W03 | Salon d'entraînement |
| W04 | Infirmerie |
| W05 | Salle des opérations (expéditions) |
| W06 | Labo de recherche |
| W07 | Archives |
| W08 | Carte de la ville |
| W09 | Préparation de mission |
| W10a | Plateau — attente du lancer |
| W10b | Plateau — choix de destination |
| W11a | Combat — un allié est prêt |
| W11b | Combat — ciblage et combo |
| W12 | Mini-jeux (4 formats) |
| W13 | Événement narratif |
| W14 | Résultats (combat / zone) |
| W15 | Recrutement |
| W16 | Équipe / fiche membre |
| W17 | Pass saisonnier |
| W18 | Boutique |
| W19 | Paramètres |

### W01 — Titre / connexion

![W01](Maquettes/wireframes/W01-titre.png)

1. Logo-titre animé (apparition + éclat de l'étoile) sur l'illustration clé ; voile sombre en bas pour la lisibilité.
2. JOUER : connexion invité automatique (UGS). Si un compte est lié, la session reprend directement. Spinner + message pendant la connexion.
3. Lier un compte (Google / Apple / Steam selon la plateforme), conseillé après le prologue pour sécuriser la progression.
4. Choix de langue (FR, EN, ES, PT, DE), mémorisé.
5. Liens légaux ; le consentement RGPD s'affiche en modale au tout premier lancement.

### W02 — QG — hub (vue en coupe)

![W02](Maquettes/wireframes/W02-qg.png)

1. Barre de ressources (Crédits, PR, Gemmes) et ⚙ paramètres. Toucher une ressource explique d'où elle vient et propose la boutique.
2. Vue en coupe du QG : chaque pièce est une zone tactile avec son niveau ; elle s'anime quand quelque chose s'y passe.
3. Badges de notification : entraînement terminé, expédition revenue, labo plein, pool renouvelée.
4. MISSION : action principale, ouvre la carte de New York (toujours au même endroit, sous le pouce droit).
5. Recrutement, avec badge « N » quand une nouvelle pool est disponible.
6. Accès permanents : Équipe, Pass (palier + progression), Boutique.
7. Bandeau des objectifs secondaires en temps réel (compte à rebours jusqu'à la prochaine vague) ; toucher = carte filtrée.
8. Missions quotidiennes (XP de pass), réclamables d'un geste.

### W03 — Salon d'entraînement

![W03](Maquettes/wireframes/W03-salon.png)

1. Retour au QG (bouton, geste retour Android ou Échap sur PC) — identique sur tous les écrans de pièce.
2. Emplacement occupé : membre, XP en cours, minuteur, accélération en Gemmes (20 GM/heure) ou récupération.
3. Emplacement libre : ouvre la liste de l'effectif triée par niveau ; emplacements verrouillés affichés avec leur niveau de déblocage.
4. Objets du salon placés et bonus d'XP cumulé ; accès à la boutique d'objets.
5. Paliers de compétences débloqués par le niveau, validés en Crédits (puits principal).
6. Amélioration de la pièce (coût, effet du niveau suivant).

### W04 — Infirmerie

![W04](Maquettes/wireframes/W04-infirmerie.png)

1. Emplacement occupé : fatigue qui descend en temps réel, multiplicateur de récupération, minuteur, accélération.
2. Effectif trié par fatigue décroissante ; « Placer » envoie le membre dans un emplacement libre.
3. Tri (fatigue, niveau, famille). Code couleur de la jauge : vert < 60 %, orange au-delà (malus), rouge à 100 % (indisponible).
4. Consommable « Trousse de soin » utilisable sans emplacement.

### W05 — Salle des opérations (expéditions)

![W05](Maquettes/wireframes/W05-operations.png)

1. Expéditions en cours : zone, durée, membres, minuteur ; « Récupérer » quand c'est terminé (badge sur le QG).
2. Nouvelle expédition (2 emplacements au niv. 1, 4 au niv. 7).
3. Durées 1 h / 4 h / 8 h / 12 h (8 h et 12 h débloquées par le niveau de la pièce).
4. Membres disponibles (ni en escouade de mission, ni au salon, ni à l'infirmerie).
5. Aperçu des gains et de la fatigue avant l'envoi.
6. Envoi : lance le minuteur et notifie au retour (notification push optionnelle).

### W06 — Labo de recherche

![W06](Maquettes/wireframes/W06-labo.png)

1. Jauge de stock (12 h de production, 24 h au niv. 5) : au-delà, la production s'arrête.
2. Production horaire et temps restant avant saturation.
3. Collecte d'un geste (animation des PR vers la barre de ressources).
4. Amélioration de la pièce.

### W07 — Archives

![W07](Maquettes/wireframes/W07-archives.png)

1. Onglets : recrues, lore, scènes débloquées, musiques, succès.
2. Cartes de collection ; les recrues non rencontrées restent en silhouette « ??? ».
3. Détail : illustration, identité, bio courte ; lien vers la fiche complète (W16).
4. Progression de la collection de la ville (pool épuisée = collection terminée).

### W08 — Carte de la ville

![W08](Maquettes/wireframes/W08-carte.png)

1. Arrondissement = acte ; les actes non débloqués restent grisés et voilés.
2. Zones (3 par acte) : validée, en cours, disponible, verrouillée. Ordre libre à l'intérieur d'un acte.
3. Objectif secondaire temps réel présent dans une zone validée.
4. Fiche de la zone : objectifs (cochés s'ils sont déjà remplis), récompenses de validation, état de la partie en cours.
5. Mode difficile, débloqué par la validation de la zone.
6. Vers la préparation de mission (W09).

### W09 — Préparation de mission

![W09](Maquettes/wireframes/W09-preparation.png)

1. Escouade de 4 : portrait, famille, fatigue, niveau. Toucher = retirer ; un membre à 100 % de fatigue ne peut pas être placé.
2. Effectif disponible (anneau de fatigue autour du portrait) ; glisser-déposer ou toucher pour remplir l'emplacement libre.
3. Filtres par famille.
4. Combos de l'escouade (les 6 paires), duos légendaires mis en avant : aide à composer l'équipe.
5. Consommables de mission emportés (achetés en Crédits).
6. Rappel des objectifs de la zone et niveau conseillé.
7. Déployer : ouvre le plateau (W10) ; avertissement si un membre dépasse 60 % de fatigue.

### W10a — Plateau — attente du lancer

![W10a](Maquettes/wireframes/W10a-plateau-lancer.png)

1. Objectifs de la zone (3), cochés même si le brouillard se referme ; toucher = centre la caméra sur l'objectif révélé.
2. Pion de l'escouade sur sa case. Glisser = déplacer la caméra, pincer = zoom.
3. LANCER ! : 1d6 (grande face du dé + animation). Raccourci : Espace.
4. Dé bonus (6 PM non utilisés = 1 dé, réserve max 2) et jauge de PM en réserve.
5. Sac : consommables emportés (trousse, dé chargé, fusée éclairante…).
6. Escouade : portraits + fatigue ; toucher = fiche rapide.
7. Brouillard : les cases au-delà du rayon de vision restent cachées (« ? ») ; il se referme quand on quitte la zone.

### W10b — Plateau — choix de destination

![W10b](Maquettes/wireframes/W10b-plateau-destination.png)

1. Destinations atteignables avec les PM du lancer : anneau pulsé + coût en pas (pastille).
2. PM en main.
3. Terminer : les PM restants vont dans la réserve de dé bonus.
4. Appui long (survol sur PC) : type de case, rang de combat, ressource déjà ramassée, etc.
5. Arrêt de brouillard : si un pas révèle du terrain, le pion s'arrête et le joueur peut repartir avec ses PM restants.
6. Chemin prévisualisé (le plus court) ; on ne traverse pas un combat non résolu.

### W11a — Combat — un allié est prêt

![W11a](Maquettes/wireframes/W11a-combat-pret.png)

1. Barre du haut : Retraite (confirmation : défaite + recul d'une case), AUTO, vitesse ×1/×2.
2. Ennemis : PV (épais) et jauge ATB (fine) au-dessus de chaque figure ; le boss a un cadre doré.
3. 4 portraits en bas : PV, ATB, fatigue. Un allié prêt s'illumine et est sélectionné automatiquement (le plus ancien prêt).
4. Ses 3 compétences s'ouvrent au-dessus : nom, effet court, recharge restante (grisée). Raccourcis Q/W/E, portraits 1-4.
5. Retours visuels : chiffres flottants, critiques en jaune, « RATÉ », secousse de la cible.
6. Statuts actifs de l'unité (icône + durée), détaillés à l'appui long.

### W11b — Combat — ciblage et combo

![W11b](Maquettes/wireframes/W11b-combat-ciblage.png)

1. Compétence mono-cible choisie : les cibles valides pulsent ; toucher = lancer. Toucher ailleurs = annuler (Échap).
2. Compétence en cours de ciblage mise en évidence.
3. COMBO : apparaît quand deux alliés prêts forment une paire ; les deux consomment leur tour. Raccourci C.
4. AUTO activé : panneau de compétences masqué, l'IA joue (combos inclus). La jauge ne s'arrête jamais (temps actif).
5. Plusieurs alliés prêts : toucher un autre portrait prêt change la sélection (Tab sur PC).

### W12 — Mini-jeux (4 formats)

![W12](Maquettes/wireframes/W12-mini-jeux.png)

1. Commun : choix du membre (sauf Puzzle), « Ignorer » sans récompense, option « temps étendu » en accessibilité.
2. Démonstration : un curseur balaie la jauge ; s'arrêter dans la zone (élargie si la famille du membre correspond). 3 essais, 2 réussites.
3. Piratage : faire pivoter les segments pour relier source et sortie, 30 s (+10 s avec Boussole ou Étincelle).
4. Poursuite : suite de 6 à 10 gestes chronométrés, 2 erreurs tolérées.
5. Intervention : la chance de réussite de chaque membre est affichée avant de confirmer.

### W13 — Événement narratif

![W13](Maquettes/wireframes/W13-evenement.png)

1. Illustration plein cadre façon case de comics (IA + retouche, charte DA).
2. Titre en lettrage (Bangers).
3. Texte court (3-4 lignes max), avance au toucher si plus long.
4. 2-3 choix, conséquence annoncée (ou masquée « ??? » pour les choix de scénario) ; un choix peut être lié à un membre présent.
5. Membre qui parle : portrait en médaillon, sa réplique peut être doublée.

### W14 — Résultats (combat / zone)

![W14](Maquettes/wireframes/W14-resultats.png)

1. Bandeau Victoire / Défaite (défaite : « l'équipe recule d'une case »).
2. Récompenses qui défilent vers la barre de ressources ; validation serveur du combat (rejeu) en tâche de fond.
3. Escouade : fatigue avant → après (+12 %, +15 % de plus en défaite), XP gagnée, montée de niveau.
4. Progression des objectifs de la zone.
5. Continuer : retour au plateau (ou au QG si toute l'escouade est épuisée).
6. Variante fin de zone : récompenses de validation et déblocage du mode difficile, retour au QG.

### W15 — Recrutement

![W15](Maquettes/wireframes/W15-recrutement.png)

1. Pool du jour : 5 cartes, choix direct à coût fixe en PR (pas de gacha, pas de doublons).
2. Rareté (Agent / Élite / Légende) : cadre et coût croissants ; une Légende liée à l'histoire entre dans la pool après chaque mini-climax.
3. Renouvellement : 1 gratuit par jour, puis 3 000 Crédits, puis 50 Gemmes.
4. Collection de la ville : pool épuisée = collection terminée.
5. Toucher une carte : fiche complète (W16) avant d'acheter ; confirmation d'achat en modale.

### W16 — Équipe / fiche membre

![W16](Maquettes/wireframes/W16-fiche-membre.png)

1. Effectif : grille de portraits, tri et filtres (famille, rareté, niveau, fatigue).
2. Illustration en pied ; balayer à gauche/droite = membre suivant.
3. Statistiques au niveau actuel (malus de fatigue affiché en orange s'il s'applique).
4. Compétences actives et passive avec description générée à partir des effets ; losanges = paliers validés.
5. Validation du prochain palier (niveau requis atteint).
6. Combos du membre, duo légendaire en tête.
7. XP et fatigue ; raccourcis vers le salon et l'infirmerie.

### W17 — Pass saisonnier

![W17](Maquettes/wireframes/W17-pass.png)

1. Palier actuel, progression d'XP, temps restant de la saison (42 jours, 50 paliers).
2. Deux pistes alignées par palier : gratuite (Crédits, PR, objets) et premium (tenues, thème de QG, Gemmes, PR).
3. Marqueur du palier courant ; défilement horizontal, palier courant centré à l'ouverture.
4. Achat du pass premium (rétroactif sur les paliers déjà atteints).
5. Missions quotidiennes (500 XP par jour) avec réclamation.

### W18 — Boutique

![W18](Maquettes/wireframes/W18-boutique.png)

1. Onglets : offres, Gemmes, packs de PR, accélérateurs, cosmétiques (tenues, décor du QG, dés et pions).
2. Mise en avant : offre de bienvenue (une fois), offres d'événement.
3. Packs de Gemmes avec bonus croissant ; prix localisés par le store.
4. Mentions obligatoires et principe « pas de pay-to-win, pas de loot box ».

### W19 — Paramètres

![W19](Maquettes/wireframes/W19-parametres.png)

1. Catégories : audio (musique, effets, voix), affichage, accessibilité, langue, compte, confidentialité.
2. Accessibilité au lancement : taille de texte, mode daltonien (familles = icône + couleur), flashs, temps étendu, sous-titres.
3. Compte : liaison, export et suppression des données (RGPD, stores).
4. Identifiant et versions (utile au support).

## 5. Maquettes stylisées

### S01 — Titre

![S01 — Titre](Maquettes/stylisees/S01-titre.png)

L'illustration clé occupe tout l'écran ; le logo-titre domine, un seul appel à l'action (JOUER) dans la zone du pouce. Voile sombre en bas pour la lisibilité.

### S02 — QG

![S02 — QG](Maquettes/stylisees/S02-qg.png)

Chaque pièce est une case de BD avec son récitatif jaune, son niveau et son état. MISSION est le bouton le plus fort de l'écran (rouge, en haut à droite) ; les badges rouges signalent ce qui attend le joueur.

### S03 — Plateau, choix de destination

![S03 — Plateau, choix de destination](Maquettes/stylisees/S03-plateau.png)

Cases rondes encrées, couleur = type, destinations cerclées de jaune avec leur coût, chemin en pointillés. Le brouillard est une masse sombre et tramée ; un récitatif blanc annonce le nouveau secteur.

### S04 — Combat, ciblage et combo

![S04 — Combat, ciblage et combo](Maquettes/stylisees/S04-combat.png)

Les alliés sont présentés en cases inclinées façon planche splash ; les ennemis en silhouettes jusqu'à la production des illustrations. Les retours (dégâts, CRIT !, COMBO !) reprennent les onomatopées et éclats des comics.

### S05 — Recrutement

![S05 — Recrutement](Maquettes/stylisees/S05-recrutement.png)

Cinq cartes au format collection : portrait encadré, rareté en récitatif (cuivre, argent, or), bande de couleur de famille, coût en PR. La Légende est surélevée et entourée d'un halo doré.

## 6. Kit UI

![Kit UI](Maquettes/stylisees/S06-kit-ui.png)

| Composant | Règle |
|---|---|
| Bouton principal | Jaune #FFD23F, texte Bangers encre, contour noir 5 px, ombre décalée 7 px ; un seul par écran |
| Bouton danger | Rouge #E5484D (retraite, suppression, MISSION) |
| Bouton secondaire | Gris foncé #2B3140, texte blanc |
| Récitatif | Bandeau jaune (ou blanc pour un retour d'info), lettrage Bangers, ombre 5 px |
| Case de BD | Fond #1E222B, contour noir 5 px, rayon 14 px, ombre décalée 9 px, trame de points discrète |
| Jauges | PV allié vert, PV ennemi rouge, ATB jaune, fatigue verte puis orange au-delà de 60 %, bouclier bleu clair |
| Familles | Matière ambre, Élémentaire cyan, Physique/Bio rouge, Perception violet, toujours avec leur icône |
| Retours de combat | Chiffres Bangers encrés (dégâts blancs, critiques jaunes, soins verts), éclats « CRIT ! » et « COMBO ! » |

## 7. Écarts avec le prototype M1

Le prototype jouable ne couvre que : titre, QG simplifié (onglets Équipe et Recrutement + salle des opérations), plateau de la zone 1.1, combat, résultats, et les fenêtres de mini-jeu « Démonstration », d'événement et de repos. Les pièces du QG, la carte de la ville, la préparation, le pass, la boutique et les paramètres arrivent aux jalons suivants (voir `05_Production/Roadmap.md`).
